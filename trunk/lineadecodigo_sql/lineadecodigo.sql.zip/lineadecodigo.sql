-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 27, 2011 at 01:36 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lineadecodigo`
--

-- --------------------------------------------------------

--
-- Table structure for table `autores`
--

CREATE TABLE IF NOT EXISTS `autores` (
  `idautor` int(11) NOT NULL,
  `autor` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `autores`
--

INSERT INTO `autores` (`idautor`, `autor`) VALUES
(1, 'Valerio Massimo Manfredi'),
(2, 'Camilo José Cela'),
(3, 'Robert Graves');

-- --------------------------------------------------------

--
-- Table structure for table `libros`
--

CREATE TABLE IF NOT EXISTS `libros` (
  `isbn` varchar(30) CHARACTER SET latin1 NOT NULL,
  `idautor` int(11) NOT NULL,
  `titulo` varchar(250) CHARACTER SET latin1 NOT NULL,
  `descripcion` varchar(500) CHARACTER SET latin1 NOT NULL,
  `categoria` varchar(50) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`isbn`),
  KEY `isbn` (`isbn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `libros`
--

INSERT INTO `libros` (`isbn`, `idautor`, `titulo`, `descripcion`, `categoria`) VALUES
('978-84-9793-733-7', 1, 'Talos de Esparta', 'Aristrarcos, noble espartano, ha tenido un segundo hijo, Talos, débil y enfermizo.', 'Novela Histórica'),
('84-9815-212-7', 3, 'Yo, Claudio', 'Supuesta autobiografía de Claudio', 'Novela Histórica');

-- --------------------------------------------------------

--
-- Table structure for table `paises`
--

CREATE TABLE IF NOT EXISTS `paises` (
  `codigo` varchar(2) CHARACTER SET latin1 NOT NULL,
  `pais` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Dumping data for table `paises`
--

INSERT INTO `paises` (`codigo`, `pais`) VALUES
('ES', 'España'),
('FR', 'Francia'),
('US', 'Estados Unidos'),
('UK', 'Reino Unido'),
('DE', 'Alemania'),
('PT', 'Portugal'),
('JP', 'Japón');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
